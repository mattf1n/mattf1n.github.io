rm religica*.ttf
java -jar BitsNPicas.jar convertbitmap -f ttf -o religica.ttf religica/religica.sfd
java -jar BitsNPicas.jar convertbitmap -f ttf -o religicaBold.ttf religica/religicaBold.sfd
java -jar BitsNPicas.jar convertbitmap -f ttf -o religicaItalic.ttf religica/religicaItalic.sfd
