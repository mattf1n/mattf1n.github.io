![Religica screenshot](screenshot.png)

# Religica 

This is a font based on [scientifica](https://github.com/oppiliappan/scientifica),
mainly with changes to the bold and italic versions.

The bold alphabetic characters have been changed to small caps in order to make them contrast more with the normal version. The italics have been adjusted to my own tasts, making them more cursive, and preventing collisions that hurt readability.

Building with `build.sh` requires [BitsNPicas](https://github.com/kreativekorp/bitsnpicas).

